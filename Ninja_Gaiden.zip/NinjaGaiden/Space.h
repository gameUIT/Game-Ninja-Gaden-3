#pragma once

struct Space
{
	int X, Y, Width, Height, CameraX, CameraY, PlayerX, PlayerY;
};


