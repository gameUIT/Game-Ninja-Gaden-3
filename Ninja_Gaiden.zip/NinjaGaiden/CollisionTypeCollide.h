#pragma once
#include"CollisionType.h"
struct CollisionTypeCollide
{
	/* collisionType của Move Object */
	COLLISION_TYPE COLLISION_TYPE_1;
	/* collisionType của Static Object */
	COLLISION_TYPE COLLISION_TYPE_2;
};

